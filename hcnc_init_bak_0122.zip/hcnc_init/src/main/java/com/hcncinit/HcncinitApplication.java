
package com.hcncinit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HcncinitApplication {

    public static void main(String[] args) {
        SpringApplication.run(HcncinitApplication.class, args);
    }
}
